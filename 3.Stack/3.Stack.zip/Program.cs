﻿using System;

namespace _3.Stack
{
    class Program
    {
        static void Main(string[] args)
        {
            var commandInterpreter = new CommandInterpreter();
            commandInterpreter.Run();
        }
    }
}
