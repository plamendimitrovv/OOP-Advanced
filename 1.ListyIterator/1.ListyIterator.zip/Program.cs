﻿using System;

namespace _1.ListyIterator
{
    class Program
    {
        public static void Main(string[] args)
        {
            var commandInterpreter = new CommandInterpreter();
            commandInterpreter.Run(); 
        }
    }
}
